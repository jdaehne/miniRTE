<?php
/*
 * miniRTE
 *
 * German language file
 *
 */


// input Options
$_lang['minirte.buttons'] = 'Button-Konfiguration';
$_lang['minirte.buttons_desc'] = 'Buttons werden über einen JSON definiert.';
$_lang['minirte.linebreaks'] = 'Umbrüche erlauben';
