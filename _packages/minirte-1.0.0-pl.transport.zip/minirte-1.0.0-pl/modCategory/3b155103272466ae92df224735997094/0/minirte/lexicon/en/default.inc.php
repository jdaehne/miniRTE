<?php
/*
 * miniRTE
 *
 * English language file
 *
 */


// input Options
$_lang['minirte.buttons'] = 'Button-Configuration';
$_lang['minirte.buttons_desc'] = 'Buttons will be defined by a JSON.';
$_lang['minirte.linebreaks'] = 'Enable Linebreaks';
